#!/bin/bash

clear
echo "Howdie good sir!"
sleep 2
echo "This bash stuff starting to come together?"
read ans
echo "you typed $ans"
sleep 3
echo "Well, just remember Rule#: Keep. Going."


